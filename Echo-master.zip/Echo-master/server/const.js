const ECHO_API = process.env.ECHO_API;

module.exports = {
  ECHO_API: ECHO_API,
};
